const categories = [];

export const getCategories = (req, res) => {
  res.json(categories);
};

export const getCategoryById = (req, res) => {
  const category = categories.find(c => c.id === req.params.id);
  if (!category) return res.status(404).json({ message: 'Category not found' });
  res.json(category);
};

export const createCategory = (req, res) => {
  const category = {
    id: Date.now().toString(),
    ...req.body,
    createdAt: new Date()
  };
  categories.push(category);
  res.status(201).json(category);
};

export const updateCategory = (req, res) => {
  const index = categories.findIndex(c => c.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Category not found' });
  
  categories[index] = {
    ...categories[index],
    ...req.body,
    updatedAt: new Date()
  };
  
  res.json(categories[index]);
};

export const deleteCategory = (req, res) => {
  const index = categories.findIndex(c => c.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Category not found' });
  
  categories.splice(index, 1);
  res.status(204).send();
};