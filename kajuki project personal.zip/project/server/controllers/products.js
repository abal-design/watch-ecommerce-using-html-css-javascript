const products = [];

export const getProducts = (req, res) => {
  res.json(products);
};

export const getProductById = (req, res) => {
  const product = products.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ message: 'Product not found' });
  res.json(product);
};

export const createProduct = (req, res) => {
  const product = {
    id: Date.now().toString(),
    ...req.body,
    createdAt: new Date()
  };
  products.push(product);
  res.status(201).json(product);
};

export const updateProduct = (req, res) => {
  const index = products.findIndex(p => p.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Product not found' });
  
  products[index] = {
    ...products[index],
    ...req.body,
    updatedAt: new Date()
  };
  
  res.json(products[index]);
};

export const deleteProduct = (req, res) => {
  const index = products.findIndex(p => p.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Product not found' });
  
  products.splice(index, 1);
  res.status(204).send();
};