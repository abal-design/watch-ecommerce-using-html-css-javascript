const orders = [];

export const getOrders = (req, res) => {
  res.json(orders);
};

export const getOrderById = (req, res) => {
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });
  res.json(order);
};

export const createOrder = (req, res) => {
  const order = {
    id: Date.now().toString(),
    ...req.body,
    status: 'pending',
    createdAt: new Date()
  };
  orders.push(order);
  res.status(201).json(order);
};

export const updateOrderStatus = (req, res) => {
  const { status } = req.body;
  const index = orders.findIndex(o => o.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Order not found' });
  
  orders[index] = {
    ...orders[index],
    status,
    updatedAt: new Date()
  };
  
  res.json(orders[index]);
};