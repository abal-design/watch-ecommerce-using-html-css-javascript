document.addEventListener('DOMContentLoaded', () => {
    renderProducts('featured-products');
});