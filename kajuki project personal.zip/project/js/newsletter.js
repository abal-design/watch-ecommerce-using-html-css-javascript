class Newsletter {
    constructor() {
        this.form = document.getElementById('newsletter-form');
        this.init();
    }

    init() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    handleSubmit(e) {
        e.preventDefault();
        const email = e.target.querySelector('input[type="email"]').value;
        
        if (this.validateEmail(email)) {
            // Here you would typically send this to your backend
            alert('Thank you for subscribing!');
            this.form.reset();
        } else {
            alert('Please enter a valid email address');
        }
    }

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new Newsletter();
});