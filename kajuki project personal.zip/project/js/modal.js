class ProductModal {
    constructor() {
        this.modal = document.getElementById('product-modal');
        this.overlay = document.getElementById('overlay');
        this.init();
    }

    init() {
        document.addEventListener('click', (e) => {
            if (e.target.closest('.product-card')) {
                const productCard = e.target.closest('.product-card');
                if (!e.target.classList.contains('add-to-cart-btn')) {
                    const productId = parseInt(productCard.dataset.id);
                    this.showModal(productId);
                }
            }
        });

        document.querySelector('.close-modal').addEventListener('click', () => {
            this.hideModal();
        });

        this.overlay.addEventListener('click', () => {
            this.hideModal();
        });
    }

    showModal(productId) {
        const product = products.find(p => p.id === productId);
        if (!product) return;

        document.querySelector('.modal-body').innerHTML = `
            <div class="modal-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="modal-info">
                <h2>${product.name}</h2>
                <p>${product.description}</p>
                <div class="modal-price">$${product.price}</div>
                <div class="modal-actions">
                    <button class="add-to-cart-btn" data-id="${product.id}">Add to Cart</button>
                </div>
            </div>
        `;

        this.modal.classList.add('active');
        this.overlay.classList.add('active');
    }

    hideModal() {
        this.modal.classList.remove('active');
        this.overlay.classList.remove('active');
    }
}

const productModal = new ProductModal();