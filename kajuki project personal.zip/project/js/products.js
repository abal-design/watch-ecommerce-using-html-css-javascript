const products = [
    {
        id: 1,
        name: "Classic Chronograph",
        collection: "classic",
        price: 2999.99,
        description: "A timeless chronograph with premium leather strap",
        specs: {
            movement: "Automatic",
            case: "316L Stainless Steel",
            diameter: "42mm",
            waterResistance: "100m"
        },
        image: "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    },
    {
        id: 2,
        name: "Sport Diver",
        collection: "sport",
        price: 3499.99,
        description: "Professional diving watch with rotating bezel",
        specs: {
            movement: "Automatic",
            case: "Titanium",
            diameter: "44mm",
            waterResistance: "300m"
        },
        image: "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    },
    {
        id: 3,
        name: "Limited Gold Edition",
        collection: "limited",
        price: 7999.99,
        description: "Exclusive 18k gold timepiece, limited to 100 pieces",
        specs: {
            movement: "In-house Automatic",
            case: "18k Gold",
            diameter: "40mm",
            waterResistance: "50m"
        },
        image: "https://images.unsplash.com/photo-1547996160-81dfa63595aa?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    }
];

class ProductsPage {
    constructor() {
        this.productsGrid = document.getElementById('products-grid');
        this.collectionFilter = document.getElementById('collection-filter');
        this.priceFilter = document.getElementById('price-filter');
        this.init();
    }

    init() {
        this.renderProducts(products);
        this.bindEvents();
    }

    bindEvents() {
        this.collectionFilter.addEventListener('change', () => this.filterProducts());
        this.priceFilter.addEventListener('change', () => this.filterProducts());
    }

    filterProducts() {
        const collection = this.collectionFilter.value;
        const priceRange = this.priceFilter.value;
        
        let filtered = products;

        if (collection !== 'all') {
            filtered = filtered.filter(p => p.collection === collection);
        }

        if (priceRange !== 'all') {
            const [min, max] = priceRange.split('-').map(Number);
            filtered = filtered.filter(p => {
                if (max) {
                    return p.price >= min && p.price < max;
                }
                return p.price >= min;
            });
        }

        this.renderProducts(filtered);
    }

    renderProducts(products) {
        this.productsGrid.innerHTML = products.map(product => `
            <article class="product-card" data-id="${product.id}">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}">
                </div>
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <div class="price">$${product.price.toLocaleString()}</div>
                    <p class="description">${product.description}</p>
                    <div class="product-actions">
                        <button class="cta-button">Add to Cart</button>
                        <button class="view-details">View Details</button>
                    </div>
                </div>
            </article>
        `).join('');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new ProductsPage();
});