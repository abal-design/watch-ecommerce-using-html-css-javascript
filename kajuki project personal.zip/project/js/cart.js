class Cart {
    constructor() {
        this.items = [];
        this.total = 0;
        this.init();
    }

    init() {
        this.cartBtn = document.querySelector('.cart-btn');
        this.cartSidebar = document.getElementById('cart-sidebar');
        this.closeCartBtn = document.querySelector('.close-cart');
        this.cartItemsContainer = document.querySelector('.cart-items');
        this.cartCount = document.querySelector('.cart-count');
        this.cartTotal = document.querySelector('.cart-total span');
        this.overlay = document.getElementById('overlay');

        this.bindEvents();
    }

    bindEvents() {
        this.cartBtn.addEventListener('click', () => this.toggleCart());
        this.closeCartBtn.addEventListener('click', () => this.toggleCart());
        this.overlay.addEventListener('click', () => this.toggleCart());

        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('add-to-cart-btn')) {
                const productCard = e.target.closest('.product-card');
                const productId = parseInt(productCard.dataset.id);
                this.addItem(productId);
            }

            if (e.target.classList.contains('remove-item')) {
                const productId = parseInt(e.target.dataset.id);
                this.removeItem(productId);
            }
        });
    }

    toggleCart() {
        this.cartSidebar.classList.toggle('active');
        this.overlay.classList.toggle('active');
    }

    addItem(productId) {
        const product = products.find(p => p.id === productId);
        if (!product) return;

        const existingItem = this.items.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            this.items.push({ ...product, quantity: 1 });
        }

        this.updateCart();
    }

    removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.updateCart();
    }

    updateCart() {
        this.updateCartCount();
        this.updateCartTotal();
        this.renderCartItems();
    }

    updateCartCount() {
        const count = this.items.reduce((total, item) => total + item.quantity, 0);
        this.cartCount.textContent = count;
    }

    updateCartTotal() {
        this.total = this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
        this.cartTotal.textContent = this.total.toFixed(2);
    }

    renderCartItems() {
        this.cartItemsContainer.innerHTML = this.items.map(item => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}">
                <div class="cart-item-info">
                    <h4>${item.name}</h4>
                    <p class="cart-item-price">$${item.price} × ${item.quantity}</p>
                    <button class="remove-item" data-id="${item.id}">Remove</button>
                </div>
            </div>
        `).join('');
    }
}

const cart = new Cart();