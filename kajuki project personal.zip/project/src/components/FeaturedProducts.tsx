import React from 'react';
import ProductCard from './ProductCard';

const products = [
  {
    name: "Latest Smartphone",
    price: 999.99,
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Latest flagship smartphone with amazing camera capabilities"
  },
  {
    name: "Wireless Earbuds",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Premium wireless earbuds with noise cancellation"
  },
  {
    name: "Smart Watch",
    price: 299.99,
    image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "Feature-packed smartwatch for fitness and notifications"
  },
  {
    name: "Gaming Laptop",
    price: 1499.99,
    image: "https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "High-performance gaming laptop with RGB keyboard"
  }
];

export default function FeaturedProducts() {
  return (
    <div className="bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <ProductCard key={index} {...product} />
          ))}
        </div>
      </div>
    </div>
  );
}